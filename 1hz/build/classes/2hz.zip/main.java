import java.util.ArrayList;

class Pizza {
    String size;
    ArrayList<String> toppings = new ArrayList<>();
    int sum()
    {
        int out = 0;
        out += ("normal".equals(size) ? 1000 : 2500) + 100*toppings.size();
        return out;
    }
    public static void main(String[] args){
        Pizza order = new Pizza();
        order.size = System.console().readLine();
        for( String topping = System.console().readLine(); !"end".equals(topping); topping = System.console().readLine() )
            order.toppings.add(topping);
        System.out.println("Order price: " + order.sum());
    }
}
