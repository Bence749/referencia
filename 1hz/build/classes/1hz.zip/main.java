class main {
    public static void main(String[] args){
        int szam = Integer.parseInt(args[0]);
        int sum = 0;
        for(int i = 1; i < szam; i++)
        {
            if(szam % i == 0)
                sum += i;
        }
        System.out.println("A " + szam + " szám " + ((sum == szam) ? "tökéletes" : "nem tökéletes"));
    }
}
