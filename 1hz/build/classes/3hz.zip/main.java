class Kangaroo
{
    String name;
    int age;
    public Kangaroo(String name, int age)
    {
        this.name = name;
        this.age = age;
    }
    public Kangaroo(int x)
    {
        System.out.println("Number of kangaroo legs is 2.");
    }
    void display( String country )
    {
        System.out.println("The name of the Kangaroo is: " + this.name + "\nCountry: " + country
                + "\nAge: " + (++this.age));
        
    }
    public static void main(String[] args)
    {
        Kangaroo diego = new Kangaroo("Diego", 14);
        new Kangaroo(2);
        diego.display("Hungary");
    }
}